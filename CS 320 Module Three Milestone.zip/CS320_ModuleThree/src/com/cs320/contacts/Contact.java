package com.cs320.contacts;

public class Contact {

    private final String contactID; // Unique and unmodifiable
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String address;

    // Constructor
    public Contact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
        if (!this.validateID(contactID)) {
            throw new IllegalArgumentException("Invalid contact ID");
        }
        if (!this.validateFirstName(firstName)) {
            throw new IllegalArgumentException("Invalid first name");
        }
        if (!this.validateLastName(lastName)) {
            throw new IllegalArgumentException("Invalid last name");
        }
        if (!this.validatePhoneNumber(phoneNumber)) {
            throw new IllegalArgumentException("Invalid phone number");
        }
        if (!this.validateAddress(address)) {
            throw new IllegalArgumentException("Invalid address");
        }

        this.contactID = contactID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }

    // Validation methods
    private boolean validateID(String id) {
        return id != null && id.length() <= 10;
    }

    private boolean validateFirstName(String firstName) {
        return firstName != null && firstName.length() <= 10;
    }

    private boolean validateLastName(String lastName) {
        return lastName != null && lastName.length() <= 10;
    }

    private boolean validatePhoneNumber(String phoneNumber) {
        return phoneNumber != null && phoneNumber.matches("\\d{10}");
    }

    private boolean validateAddress(String address) {
        return address != null && address.length() <= 30;
    }

    // Getters
    public String getContactID() {
        return contactID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    // Setters with validation
    public void setFirstName(String firstName) {
        if (!this.validateFirstName(firstName)) {
            throw new IllegalArgumentException("Invalid first name");
        }
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        if (!this.validateLastName(lastName)) {
            throw new IllegalArgumentException("Invalid last name");
        }
        this.lastName = lastName;
    }

    public void setPhoneNumber(String phoneNumber) {
        if (!this.validatePhoneNumber(phoneNumber)) {
            throw new IllegalArgumentException("Invalid phone number");
        }
        this.phoneNumber = phoneNumber;
    }

    public void setAddress(String address) {
        if (!this.validateAddress(address)) {
            throw new IllegalArgumentException("Invalid address");
        }
        this.address = address;
    }
}
