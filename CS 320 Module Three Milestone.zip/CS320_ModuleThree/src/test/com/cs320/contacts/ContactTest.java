package com.cs320.contacts;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ContactTest {

    // Test valid constructor
    @Test
    @DisplayName("Test valid constructor")
    public void testValidConstructor() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("12345", contact.getContactID());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhoneNumber());
        assertEquals("123 Main St", contact.getAddress());
    }

    // Test invalid last name
    @Test
    @DisplayName("Test invalid last name")
    public void testInvalidLastName() {
        // Null last name
        Exception exception1 = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", null, "1234567890", "123 Main St");
        });
        assertEquals("Invalid last name", exception1.getMessage());

        // Last name too long
        Exception exception2 = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe12345678", "1234567890", "123 Main St");
        });
        assertEquals("Invalid last name", exception2.getMessage());
    }

    // Test setter for valid last name
    @Test
    @DisplayName("Test valid last name setter")
    public void testValidLastNameSetter() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contact.setLastName("Smith");
        assertEquals("Smith", contact.getLastName());
    }

    // Test setter for invalid last name
    @Test
    @DisplayName("Test invalid last name setter")
    public void testInvalidLastNameSetter() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");

        // Null last name
        Exception exception1 = assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName(null);
        });
        assertEquals("Invalid last name", exception1.getMessage());

        // Last name too long
        Exception exception2 = assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName("Doe12345678");
        });
        assertEquals("Invalid last name", exception2.getMessage());
    }
}
